/*************************************************************************
Cuyamaca College CS-181

File name:	Lab2Exercise1.cpp

Description: Lab #2, Exercise #1, Reorganize messed up code to make it work

Developer: Christopher Simaan


*************************************************************************/

#include <iostream>

using namespace std;

// A crazy mixed up program

int main() {
	cout << "In 1492 Columbus sailed the ocean blue.";

	return 0;
}