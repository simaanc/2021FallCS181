/*************************************************************************
Cuyamaca College CS-181

File name:	Lab2Exercise2.cpp

Description: Lab #2, Exercise #2, Sum of 2 Numbers

Developer: Christopher Simaan


*************************************************************************/

#include <iostream>

using namespace std;

int main() {
	//define variables
	int number1 = 50;
	int number2 = 100;
	int total = number1 + number2;

	//output addition
	cout << "The total is " << total;

	return 0;
}